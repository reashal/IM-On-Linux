﻿#ifndef LOGIN_H
#define LOGIN_H

#include <QDialog>
#include <QLabel>
#include <QLineEdit>
#include <QPushButton>
#include<Access.h>
class Login : public QDialog
{
    Q_OBJECT
public:
    explicit Login(QString* username,Access*access,QDialog *parent = 0);

signals:

public slots:
    void login();
    bool isright(QString id,QString passwd);
private:
    QString*username;
    Access* access;
    QLabel *userNameLbl;
    QLabel *pwdLbl;
    QLabel *titil;
    QLineEdit *userNameLEd;
    QLineEdit *pwdLEd;
    QPushButton *loginBtn;
    QPushButton *exitBtn;
};
#endif // LOGIN_H
