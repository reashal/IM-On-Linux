﻿#ifndef REGISTERED_H
#define REGISTERED_H

#include <QDialog>
#include <QLabel>
#include <QLineEdit>
#include <QPushButton>
#include<Access.h>
class registerd : public QDialog
{
    Q_OBJECT
public:
    explicit registerd(Access *access,QDialog *parent = 0);

signals:

public slots:
    void regist();
    void noregist();
    bool isright(QString id,QString passwd);
private:
    Access* access;
    QLabel *titil;
    QLabel *userNameLbl;
    QLabel *pwdLbl;
    QLineEdit *userNameLEd;
    QLineEdit *pwdLEd;
    QPushButton *registerdBtn;
    QPushButton *noregisterdBtn;
};


#endif // REGISTERED_H
