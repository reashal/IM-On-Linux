﻿#include "mainwindow.h"
#include<QDateTime>
mainwindow::mainwindow(QString* username,client *cli,QWidget *parent) :
    QMainWindow(parent)
{
    this->resize(700,700);
    this->setMaximumSize(700,700);
    this->cli=cli;
    this->username=username;
    cli->run();

    pri=new QLabel(this);
    pri->setText("私人聊天室");
    pri->move(50,0);

    ExitBu = new QPushButton(this);
    ExitBu->move(600,670);
    ExitBu->setText("退出");

    SendBu_pri = new QPushButton(this);
    SendBu_pri->move(600,630);
    SendBu_pri->setText("发送");

    Sendbox=new QLineEdit(this);
    Sendbox->move(50,600);
    Sendbox->resize(550,30);


    Chatbox_pri=new QTextEdit(this);
    Chatbox_pri->resize(550,550);
    Chatbox_pri->move(50,30);

    fTimer=new QTimer(this);
    connect(fTimer,SIGNAL(timeout()),this,SLOT(recvdata()));
    fTimer->start(1000);


    connect(SendBu_pri,&QPushButton::clicked,this,&mainwindow::pri_send);
    connect(ExitBu,&QPushButton::clicked,this,&mainwindow::close);
    connect(this,SIGNAL(mysignal(QString)),SLOT(printdata(QString)));
}

void mainwindow::pri_send(){ //向私人聊天室发送数据
    QDateTime current_date_time =QDateTime::currentDateTime();
    QString current_date =current_date_time.toString("yyyy.MM.dd hh:mm:ss.zzz ddd");
    QString text=current_date+" "+*username+"\n"+Sendbox->text();
    Sendbox->clear();
    senddata(text);
}
void mainwindow::senddata(QString data){ //向通信域发送数据
    cli->send_info((char*)data.toStdString().c_str());
}
void mainwindow::printdata(QString data){
    Chatbox_pri->append(data);
}
void mainwindow::recvdata(){ //从通信域中接受数据
    if(cli->flag==true){
        QString str((char*)cli->msg_rec);
        emit mysignal(str);
        cli->flag=false;
    }

}
