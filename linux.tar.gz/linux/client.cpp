#include "client.h"
#include"QString"
#include <QMainWindow>
#include <thread>
#include <functional>

client::client()
{
    flag=false;
}
void client::in_ip_defult()
{
  char ip_defult[]="47.94.1.16";
  stpcpy(ip_address,ip_defult);
  // the defult ip in Aliyun
  return ;
}
client::~client(){
//    close(soc_cli);
}
void client::in_ip(char ip_input[])
{
  stpcpy(ip_address,ip_input);
  /* If you run the server program locally, illegal input other than the IP will still connect local successfully.
     but if run in the server,the illegal input will not successfully connect.
     ( illegal input such as:"hhh" )*/
  return ;
}
int client::con_ser()
{
  soc_cli=socket(AF_INET,SOCK_STREAM,0);
  // set socket | return socket description | error -1
  // AF_INET:ipv4  SOCK_STREAM:full duplex  0:automatic choose agreement of type(2)
  if(soc_cli==-1)
  {
    printf("--failed to create socket\n");
    return 0;
  }
  // init
  memset(&servaddr,0,sizeof(servaddr));
  servaddr.sin_family=AF_INET;
  // choose ipv4 but not ipv6
  servaddr.sin_port=htons(6666);
  // defult ip  port
  if(inet_pton(AF_INET,ip_address,&servaddr.sin_addr)==-1)
  {
    printf("--failed to inet_tion\n");
    return 0;
  }
  // transform the ip address to binary
  if(connect(soc_cli,(struct sockaddr*)&servaddr,sizeof(servaddr))==-1)
  //        (description,server socket address,length of socket address)
  {
    printf("--failed to connection\n");
    return 0;
  }
  //printf("--connection success!\n");
  return 1;
}

int client::send_info(char input[])
{
  stpcpy(mess,input);
//  fgets(mess,2222,stdin);
  // buffer | stop when '\n' what want to send
  if(send(soc_cli,mess,strlen(mess),0)==-1)
  // (socket description,buffer,length,0)
  {
    printf("--failed to send this  message!\n");
    return 0;
  }
  return 1;
}

void client::con_recv()
{
    while(1)
    {
        while (flag) {
            sleep(1);
        }
        bzero(msg_rec,sizeof(msg_rec));
        fin=read(soc_cli,msg_rec,sizeof(msg_rec));
        if(!fin)
        {
            printf("--The server program is close\n");
            break;
        }
        flag=true;
    }
//    close(soc_cli);
    kill(getppid(),SIGUSR1);
    exit(EXIT_SUCCESS);

//	善后工作,关闭套接字/对接父进程
}

void client::run(){

    std::thread recv(std::bind(&client::con_recv, this));
    recv.detach();
//    pid_t k=fork();
//    if(!k) con_recv();
    return ;
}
