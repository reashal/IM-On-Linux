//
// Created by masker on 2021/11/5.
//
#include <string>
#include <iostream>
#ifndef IM_FOR_LINUX_MAIN_H
#define IM_FOR_LINUX_MAIN_H

using namespace std;

class main {

};


#endif //IM_FOR_LINUX_MAIN_H
