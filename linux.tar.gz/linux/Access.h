//
// Created by masker on 2021/11/12.
//

#ifndef IM_FOR_LINUX_ACCESS_H
#define IM_FOR_LINUX_ACCESS_H

#include <string>
#include "DUtil.h"
#include "User.h"

class Access {
public:
    DUtil dUtil;

    bool sameUserName(string username);//检测相同用户名

    bool registerUser(string username,string passwd);//注册

    bool matchIp(string username);


};


#endif //IM_FOR_LINUX_ACCESS_H
