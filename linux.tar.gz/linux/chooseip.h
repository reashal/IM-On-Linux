﻿#ifndef CHOOSEIP_H
#define CHOOSEIP_H
#include <QMainWindow>
#include <QDialog>
#include <QLabel>
#include <QLineEdit>
#include <QPushButton>
#include<client.h>
class chooseip : public QDialog
{
    Q_OBJECT
public:
    explicit chooseip(client* cli,QDialog *parent = 0);

signals:

public slots:
    void de_choose();
    void self_choose();
    bool isright();
private:
    QPushButton* default_button;
    QPushButton* self_button;
    QLineEdit* input;
    client*cli;
};


#endif // CHOOSEIP_H
