#include <QApplication>
#include "mainwindow.h"
#include "login.h"
#include"chooseip.h"
#include"registerd.h"
#include"client.h"
#include"Access.h"
int main(int argc,char** argv)
{
    QApplication app(argc,argv);
    QString* username=new QString;
    client*cli=new client();
    Access*access=new Access;
    registerd reg(access);
    if(reg.exec()==QDialog::Accepted){
        Login login(username,access);
        if (login.exec() == QDialog::Accepted)
        {
            chooseip ci(cli);
            if(ci.exec()==QDialog::Accepted){
                mainwindow *main = new mainwindow(username,cli);
                main->setWindowTitle("聊天");
                main->show();
                return app.exec();
            }
            return 0;
        }
    }
    else return 0;
}
