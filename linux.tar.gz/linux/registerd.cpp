﻿#include "registerd.h"
#include <QMessageBox>

registerd::registerd(Access *access,QDialog *parent) :
    QDialog(parent)
{
    //设置窗体标题
    this->setWindowTitle("注册界面");
    this->access=access;

    titil=new QLabel(this);
    QFont font;
    font.setPointSize(15); // 设置字号
    titil->setFont(font);  // 设置字体
    titil->resize(100,50);
    titil->setText("注册");
    titil->adjustSize();
    titil->move(150,30);

    //用户名Label
    userNameLbl = new QLabel(this);
    userNameLbl->move(70,80);
    userNameLbl->setText("用户名:");

    //用户名输入框
    userNameLEd = new QLineEdit(this);
    userNameLEd->move(130,80);
    userNameLEd->setPlaceholderText("请输入用户名!");

    //密码Label
    pwdLbl = new QLabel(this);
    pwdLbl->move(80,130);
    pwdLbl->setText("密码:");

    //密码输入框
    pwdLEd = new QLineEdit(this);
    pwdLEd->move(130,130);
    pwdLEd->setPlaceholderText("请输入密码!");
    pwdLEd->setEchoMode(QLineEdit::Password);//输入的密码以圆点显示

    //登录按钮
    registerdBtn = new QPushButton(this);
    registerdBtn->move(80,200);
    registerdBtn->setText("注册");

    //退出按钮
    noregisterdBtn = new QPushButton(this);
    noregisterdBtn->move(170,200);
    noregisterdBtn->setText("我已注册");

    //单击登录按钮时 执行 registerd::registerd 槽函数；//单击退出按钮时 执行 registerd::close 槽函数
    connect(registerdBtn,&QPushButton::clicked,this,&registerd::regist);
    connect(noregisterdBtn,&QPushButton::clicked,this,&registerd::noregist);


}

void registerd::regist()
{
    if(isright(userNameLEd->text().trimmed(),pwdLEd->text()))
    {
        QMessageBox::information(this, "注册成功",
                    "注册成功",
                    QMessageBox::Yes);
       accept();//关闭窗体，并设置返回值为Accepted
    } else {
       QMessageBox::warning(this, "警告！",
                   "用户名或密码不能为空！",
                   QMessageBox::Yes);
       // 清空内容
       userNameLEd->clear();
       pwdLEd->clear();
       //定位光标
       userNameLEd->setFocus();
    }
}
void registerd::noregist(){
    int res=QMessageBox::warning(this, "警告！",
                "确定已注册？",
                 QMessageBox::Yes | QMessageBox::No);
    switch (res){
        case QMessageBox::Yes:accept();break;
        case QMessageBox::No:break;
    default:break;
    }

}
bool registerd::isright(QString id,QString passwd){//核验账号密码不为空
    if(id.isEmpty()||passwd.isEmpty()){
        return false;
    }
    bool flag=access->registerUser(id.toStdString(),passwd.toStdString());
    return flag;
}
