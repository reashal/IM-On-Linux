﻿#include "chooseip.h"
#include <QMessageBox>

chooseip::chooseip(client*cli,QDialog *parent):QDialog(parent)
{
    this->setWindowTitle("选择IP登录方式");
    this->resize(400,150);
    this->cli=cli;

    default_button=new QPushButton(this);
    default_button->setText("选择默认IP");
    default_button->move(20,20);

    self_button=new QPushButton(this);
    self_button->setText("选择自己输入IP");
    self_button->move(20,90);

    input=new QLineEdit(this);
    input->move(150,90);

    connect(default_button,&QPushButton::clicked,this,&chooseip::de_choose);
    connect(self_button,&QPushButton::clicked,this,&chooseip::self_choose);
}
void chooseip::de_choose()
{
    cli->in_ip_defult();
    if(isright())
    {
       accept();//关闭窗体，并设置返回值为Accepted
    } else {
       QMessageBox::warning(this, "警告！",
                   "ip错误",
                   QMessageBox::Yes);
//       清空内容
       input->clear();
       //定位光标
       input->setFocus();
    }
}

void chooseip::self_choose()
{
    QString ip=input->text().trimmed();
    cli->in_ip((char*)ip.toStdString().c_str());
    if(isright())
    {
       accept();//关闭窗体，并设置返回值为Accepted
    } else {
       QMessageBox::warning(this, "警告！",
                   "ip错误",
                   QMessageBox::Yes);
//       清空内容
       input->clear();
       //定位光标
       input->setFocus();
    }
}

bool chooseip::isright(){//核验ip是否符合
    if(cli->con_ser()==0)
        return false;
    return true;
}
