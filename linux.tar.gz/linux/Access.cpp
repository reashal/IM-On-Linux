//
// Created by masker on 2021/11/12.
//

#include "Access.h"

using namespace std;

//检测用户名是否重复,重复则true
bool Access::sameUserName(string userName) {
    bool flag = false;

    //连接数据库
    dUtil.OpenDB();

    if (dUtil.queryUserName(userName)){
        flag = true;
        cout << "用户名重复！" << endl;
    }
    return flag;
}

//注册用户
bool Access::registerUser(string userName,string passwd){
    bool flag = false;

    dUtil.OpenDB();

    if (dUtil.insertUser(userName,passwd)){
        flag = true;
        cout << "注册成功！" << endl;
    }
    return flag;
}

//获取ip
bool Access::matchIp(string username) {
    bool flag = false;
    vector<User> user;

    dUtil.OpenDB();

    if (dUtil.queryIP(username,user)){
        vector<User>::iterator vecIter;
        cout << "username = " + username + "ip : " + vecIter->getIp() << endl;
        flag = true;
    }
    return flag;
}

