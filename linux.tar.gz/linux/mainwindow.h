﻿#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QLabel>
#include <QPushButton>
#include<QLineEdit>
#include<QTextEdit>
#include<client.h>
#include<QTimer>
#include <unistd.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <sys/wait.h>

class mainwindow : public QMainWindow
{
    Q_OBJECT
public:
    explicit mainwindow(QString* username,client* cli,QWidget *parent = 0);

signals:
    void mysignal(QString);
public:
    QTimer *fTimer;
public slots:
    void pri_send();
    void senddata(QString);
    void recvdata();
    void printdata(QString);

private:
    QString*username;
    char*recv[4096];
    int* fd;
    QLabel* pri;
    QTextEdit *Chatbox_pri;
    QLineEdit*Sendbox;
    QPushButton * ExitBu; //退出按钮
    QPushButton *SendBu_pri;
    client*cli;
};

#endif // MAINWINDOW_H
