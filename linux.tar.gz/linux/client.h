#ifndef CLIENT_H
#define CLIENT_H
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<netdb.h>
#include<signal.h>
#include<unistd.h>
#include<iostream>
#include<pthread.h>
#include<sys/types.h>
#include<arpa/inet.h>
#include<sys/socket.h>
#include<netinet/in.h>
#include <atomic>
using namespace std;

class client
{
public:
    client();
    ~client();
    void in_ip_defult();
    void in_ip(char ip_input[]);
    int con_ser();
    void con_recv();
    int send_info(char input[]);
    void run();
    std::atomic_bool flag;
    char *msg_rec[2048];
private:
    char mess[2048],ip_address[20],l_ip[20]="";
    int soc_cli,soc_rec,con_rec,fin,l_len;
    struct sockaddr_in  servaddr,cliaddr,localaddr;
    pthread_t rcv;
};

#endif // CLIENT_H
