#ifndef CHAT_H
#define CHAT_H

#include <QWidget>

class chat : public QWidget
{
    Q_OBJECT
public:
    explicit chat(QWidget *parent = nullptr);

signals:

};

#endif // CHAT_H
