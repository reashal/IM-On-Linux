#include "chat.h"

chat::chat(QWidget *parent) : QWidget(parent)
{

}
